package sortingorders;

import java.util.Comparator;
import java.util.TreeSet;

public class StringBufferDemo {
public static void main(String[] args) {
	TreeSet ts=new TreeSet<>(new  MyoWnComparator());
	ts.add(new StringBuffer("Asha"));
	ts.add(new StringBuffer("ramu"));
	ts.add(new StringBuffer("kumar"));
	ts.add(new StringBuffer("shekar"));
	System.out.println(ts);
	}
}
class MyoWnComparator implements Comparator{

	@Override
	public int compare(Object o1, Object o2) {
		String n1=o1.toString();
		String n2=o2.toString();		 
		return n1.compareTo(n2);
	}
}