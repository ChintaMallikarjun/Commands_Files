package sortingorders;
import java.util.Comparator;
import java.util.TreeSet;

class employee{
	 String name ;
	 Integer id;
	public employee(String name,Integer id) {
		this.name=name;
		this.id=id;
}
	public String toString() {
		return name +"   "+id;
	}
}

public class customizedDemo {
public static void main(String[] args) {
	employee e1=new employee("zee", 5);
	employee e6=new employee("maa", 7);
	employee e5=new employee("Asha", 58);
	employee e2=new employee("janaki", 15);
	employee e3=new employee("uni", 51);
	employee e4=new employee("raki", 8);
		
TreeSet<employee> s=new TreeSet<>(new MyIdcomparator());
s.add(e1);s.add(e2);s.add(e3);s.add(e4);s.add(e5);s.add(e6); 

System.out.println(s);
}}

class MyNamecomparator implements Comparator{

	@Override
	public int compare(Object o1, Object o2) {
		 employee e1=(employee)o1;
		 employee e2=(employee)o2;
		 String name1=e1.name;
		 String name2=e2.name;
		 
		 return name1.compareTo(name2);
	}}
class MyIdcomparator implements Comparator {

	@Override
	public int compare(Object o1, Object o2) {
		employee e1=(employee)o1;
		employee e2=(employee)o2;
		Integer id1= e1.id;
		Integer id2=e2.id;
		if(id1<id2){
			return -1;}
		else if(id1>id2)
		{return 1; }else
		return 0;
	}}