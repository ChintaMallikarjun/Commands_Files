package PrimeNumbers;

public class PrimarykeyDemo {
public static void main(String[] args) {
/*	primaryDemo();evenNumber();febonnaciSeries();
	febonnaciSeriesStepOneOnly(); //trail();
*/	
	ArmStrongNo(153);
}
public static void primaryDemo(){
System.out.print("The prime Numbers = ");
for(int i=1;i<=55;i++){

if(i%2!=0){
System.out.print(" "+i);} //if close
}// for close
}//method
public static void evenNumber(){
	System.out.println();
	System.out.print("The Even Numbers = ");
	for(int i=1;i<55;i++){
		if(i%2==0){System.out.print(" "+i);}
	}
}
public static void febonnaciSeries(){
	int f1=0,f2=1,f3; 
	System.out.println();
	System.out.print("febonnacce Series ="+f1+" "+f2);  // 0 1
	for(int i=1;i<25;i++){
		f3=f1+f2;					//f3=0+1=1,1+1=2,1+2=3,2+3=5,....==>1,2,3,5,
		System.out.print(" "+f3);   //
		f1=f2;
		f2=f3;
	}
}
public static void febonnaciSeriesStepOneOnly(){
	int f1=0,f2=1,f3,counter=0; 
	System.out.println();
	System.out.print("febonnacci Series stepOne ="+f1+" "+f2);  // 0 1
	for(int i=1;i<25;i++){
		counter++;
		f3=f1+f2;					//f3=0+1=1,1+1=2,1+2=3,2+3=5,....==>1,2,3,5,
	if(counter%2==0){	System.out.print(" "+f3); }  //
		f1=f2;
		f2=f3;
	
	}
}
public static void ArmStrongNo(int a){
	//(1+5+3)3=153;
 int num=a,Total=0,b,c=num;
 System.out.println(c);System.out.println(num);
 while(c != 0){
	 
 b=c%10;   			//c=153%10 =3,5,1 ;
 c=c/10;			//
 Total =Total+(b*b*b);
 }
System.out.println("ArmStrong No = "+Total);	
System.out.println("*************************");
}

public static void trail(){int t=153; int b,c; b=t%10;c=t/10;System.out.println("****888888="+b);
System.out.println("**** ="+c);
}
}