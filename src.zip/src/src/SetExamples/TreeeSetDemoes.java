package SetExamples;

import java.util.ArrayList;
import java.util.Collections;
import java.util.TreeSet;

public class TreeeSetDemoes {
public static void main(String[] args) {
	t e1=new t("dfasf");t e2=new t("df");t e3=new t("sf");t e4=new t("ff");
	
	ArrayList<  t> h=new ArrayList<>();h.add(e1);h.add(e2);h.add(e3);h.add(e4);
	//TreeSet<t> h= new TreeSet<>(); 
	 System.out.println(h); 
	 
}
}
class t implements Comparable{String name;
	public t(String name) {
		 this.name=name;
	}
	public String toString(){return name+" ";}
	@Override
	public int compareTo(Object arg0) {
		 
		return 0;
	}
}