package SetExamples;



import java.util.Comparator;
import java.util.TreeSet;

class Employee implements Comparable{
	String name;Integer id;
	 // Employee() {}
	  Employee(String name,Integer id){
		  this.name=name;
		  this.id=id;
	  }
	public String toString(){
		return "Name = "+name+" id ="+id;
	
	}
	@Override
	public int compareTo(Object o) {
		 int id1=this.id;
		 Employee e=(Employee)o;
		 int id2=e.id;
		 if(id1<id2){return -1;}else if(id1>id2){return 1;}else
		return 0;
	}
}

class Ourcomparator implements Comparator{
		
	 @Override
	public int compare(Object o1, Object o2) {
		 Employee e1=(Employee)o1;
		 Employee e2=(Employee)o2;
		 String s1=e1.name;
		 String s2=e2.name;
		 		 
		return s1.compareTo(s2);
	}
}
 
public class EmployeeInTreeSet {
public static void main(String[] args) {
	Employee e4=new Employee("ram",2);
	Employee e1=new Employee("amar",21);
	Employee e2=new Employee("ramesh",12);
	Employee e3=new Employee("sraman",9);
	
	
	TreeSet t=new TreeSet<>();
	t.add(e1);t.add(e2);t.add(e3);t.add(e4);
	System.out.println("Based upon  Sorting is Id="+t);
	
	TreeSet t1=new TreeSet<>(new Ourcomparator());
	t1.add(e1);t1.add(e2);t1.add(e3);t1.add(e4);
	System.out.println("Based upon name Sorting"+t1);
	
	TreeSet t2=new TreeSet<>();
	//person p1=new person("w", 2);person p2=new person("A", 12);person p3=new person("j", 5);
	
	
	t2.add("z1");t2.add("p2");t2.add("a3");
	System.out.println("This is person ="+t2);
	System.out.println(t2.comparator());
	
	
}
}
class person{
	String name;
	Integer vId;
	person(String name,Integer vId) {
		this.name=name;
		this.vId=vId;
	 }
	public String toString(){
		return "Person Name ="+name+" vid ="+vId;
	}
	
	
	
}
