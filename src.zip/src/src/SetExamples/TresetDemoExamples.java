package SetExamples;

import java.util.Comparator;
import java.util.TreeSet;

public class TresetDemoExamples {
 
	public static void main(String[] args) {
		p g1=new p("z",1 );
		p g2=new p("b",14 );
		p g3=new p("c",51 );
		TreeSet t=new TreeSet<>();
		t.add(g1);
		t.add(g2);
		t.add(g3); System.out.println(t);
	}}
class p implements Comparable{//	p k1=new p("z",1 );p k2=new p("b",14 );p k3=new p("c",51 );
	
	String name;Integer id;
		  p(String name,Integer id) {
		 this.name=name;this.id=id;
	}public String toString(){ return  name+"  "+ id;}
	@Override
	public int compareTo(Object o) {
	 int id1=this.id;
	 p i=(p)o;
	 int id2=i.id;
	 if(id1<id2){return -1;}else if(id1>id2){return 1;}
	 else	return 0;
	}
}
class MYOwnComparator implements Comparator {
	@Override
	public int compare(Object a1, Object a2) {
		p k1=(p)a1; 
		p k2=(p)a2; 
		String s1= k1.name;
		String s2= k2.name;
		return  s1.compareTo(s2);
	}
	
}
