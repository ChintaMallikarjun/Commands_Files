package SetExamples;

import java.util.Comparator;
import java.util.TreeSet;

public class gg {
	public static void main(String[] args) {
		employ e1=new employ("kumar", 4);
		employ e2=new employ("swam", 44);
		employ e3=new employ("murali", 43);
		employ e4=new employ("ali",33);
		employ e5=new employ("jagadhish", 22);
		TreeSet t=new TreeSet<>(new mycomparator());
		t.add(e1);t.add(e2);t.add(e3);t.add(e4);t.add(e5);
		System.out.println(t);
		System.out.println("this is head set="+t.headSet(e3));
		System.out.println("tailset="+t.tailSet(e3));
		System.out.println("first="+t.first());
		System.out.println("last="+t.last());
		System.err.println("subset="+t.subSet(e1, e3));
		System.out.println(t.pollFirst());
	}

}
class employ  {
	String name;
	Integer id;
	public employ(String name,Integer id) {
		this.name=name;
		this.id=id;
		}
	public String toString(){
		return name+"  "+id;
	}
 }

class mycomparator implements Comparator{

	@Override
	public int compare(Object o1, Object o2) {
		employ e1=(employ)o1;
		employ e2=(employ)o2;
		String n1=e1.name;
		String n2=e2.name;
		return n1.compareTo(n2);
		 
	}
	
}








