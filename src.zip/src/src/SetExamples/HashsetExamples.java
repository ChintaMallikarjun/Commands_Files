package SetExamples;

import java.util.Collections;
import java.util.HashSet;
import java.util.SortedSet;
import java.util.TreeSet;

public class HashsetExamples {
	
	public static void main(String[] args) {
		HashSet<Integer> h1=new HashSet<>();
		
		HashSet<Integer> h=new HashSet<>();
		h.add(4);h.add(42);h.add(24);h.add(49);h.add(3);h.add(5);
		
		System.out.println("h="+h);
		h1=(HashSet<Integer>) h.clone();
		System.out.println("clone="+ h.clone());h.clear();System.out.println("hashcode="+h.hashCode());
		
		System.out.println("h="+h);
		System.out.println("h="+h1);
		Collections.reverseOrder();
		h1.toArray();
		
		 SortedSet<Integer> in=new TreeSet<>(h1);
		System.out.println("TreeSet="+in);
		System.out.println("Head set ="+in.headSet(24));
		System.out.println("tail set ="+in.tailSet(24));
		System.out.println("last="+in.last());
		System.out.println("first="+in.first());
		System.out.println("subset="+in.subSet(1, 5));
		in.add( new Integer(12));
		System.out.println("TreeSet="+in);
		
	}
}
