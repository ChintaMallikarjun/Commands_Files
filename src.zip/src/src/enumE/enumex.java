package enumE;

public class enumex {
	
	enum day{ MON,TUE,WED,THU,FRI,SAT }
	//private static final char[] COLOR ='GREEN';
	public static void main(String[] args) {
		//System.out.println(day.TUE);
		//System.out.println(day.MON);
		for(day d: day.values()){
			System.out.print(d+" ");
		}
	//	for(day i;;){System.out.println();}
	}
}
