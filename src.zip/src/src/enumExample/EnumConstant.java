package enumExample;

public class  EnumConstant extends Thread {
	public static void main(String[] args) {
		EnumConstant t = new EnumConstant();
		t.start();
		try {
			t.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		for(int i=1;i<5;i++) {
			
				System.out.println("Main..");
		
			
		}
	}

	@Override
	public void run() {
		for(int i=1;i<20;i++) {
			try {
				Thread.sleep(1000);
				System.out.println("I..");
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}
}
