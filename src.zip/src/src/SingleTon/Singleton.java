package SingleTon;

//LAZY SINGLETON Instialization
public class Singleton {

	 private  static Singleton instance=null;
	 private Singleton(){}
	 
	 public  static Singleton getInstance() {
		 if(instance == null){
			 return  instance=new Singleton();
		 }
		 else return instance;
	 }
}

//EAGER SINGLETON instialization
class EagerSingleton{
	private static EagerSingleton instance=new EagerSingleton();
	private EagerSingleton(){}
	public static EagerSingleton getInstance(){
		return instance;
	}
}

// SYNCHRONIZED SINGLETON Instialization
class SynchronizedSingleton{
private static SynchronizedSingleton instance= null;
private SynchronizedSingleton() {
	// TODO Auto-generated constructor stub
}
	public static SynchronizedSingleton getInstance(){
		if(instance==null){
			synchronized (SynchronizedSingleton.class) {
				return instance=new SynchronizedSingleton();
					}
	}
		return instance;
}
}


class synchronizedDemo{
	static private synchronizedDemo instance=null;
	private synchronizedDemo(){}
	
	public static  synchronizedDemo getInstance(){
		synchronized(synchronizedDemo.class){
			if(instance==null){ return	instance=new synchronizedDemo();}
			else{ return instance;}
		}
				
		 
	}
}

class TestDemo{
	public static void main(String[] args) {
		Singleton st1=Singleton.getInstance();
		Singleton st2=Singleton.getInstance();
		
	System.out.println(	st1==st2);
	System.out.println(	st1.equals(st2));
		EagerSingleton. getInstance();
		SynchronizedSingleton .getInstance();
		
	}
}