package SingleTon;

public class singletoncheking {
	
	private static singletoncheking single=new singletoncheking( );
	
	private singletoncheking(){}
	public static singletoncheking getInstance(){
		if(single==null){
			return single=new singletoncheking();
		}else{
			return single;}
	}  private static void acess(){}
}

class Ruby{
	public static void main(String[] args){
		singletoncheking st=singletoncheking.getInstance();
		System.out.println("kjkh kjhjkhj "+st);
	}
}

