package SingleTon;

public class febbonacci {
public static void main(String[] args) {
	int f1,f2,f3;
	f1=0;f2=1;f3=f1+f2;
	System.out.print("fibbonacci nos="+f1+"  "+f2+" "+f3);
	for(int i=1;i<10;i++){
		 f1=f2;
		f2=f3;
		f3=f1+f2;
		System.out.print(" "+f3);
	}
}
}
//A Prime Number can be divided evenly only by 1, or itself. 
//And it must be a whole number greater than 1. Example: 5 can only be divided evenly by 1 or 5, 
//so it is a prime number. 
//But 6 can be divided evenly by 1, 2, 3 and 6 so it is NOT a prime number (it is a composite number).
