package String.MethodExamples;

public class string_matches {
public static void main(String[] args) {
	String s="vvc ggh jji";
	
	System.out.println(s.matches("ggh"));
	System.out.println(s.matches(s));
	System.out.println(s.regionMatches(4,"ggh",3,3));
	System.out.println(s.substring(5));
}
}
