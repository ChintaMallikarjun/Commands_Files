package String.MethodExamples;

public class methodExamples {
public static void main(String[] args) {
	
	String t1="this is how are you";
	System.out.println("is index = "+t1.indexOf("is"));
	System.out.println("are index = "+t1.indexOf("are"));
	System.out.println("you index = "+t1.indexOf("you"));
	//indexOf() returns to the first time occurance
	int h1=t1.indexOf("is");
	int h2=t1.indexOf("you");
	System.out.println(h1+"    "+h2);
	//System.out.println("are--> is a one string part index = "+t1.indexOf("are"));
	
	int h3=t1.indexOf("is",4);System.out.println(h3);
	int h4=t1.indexOf("you",8);
	System.out.println(h4);
	System.out.println(t1.indexOf('e'));
	
	
	
	/*String n=" this is raj kumar how do you do";
	String[] k=n.split("\\s");
	for(String i:k){System.out.println(i);}
	*/
	String w="how dude you dude okay";
	String[] k1=w.split(" ",0);
	for(String i:k1){System.out.println(i);}
	System.out.println(w.indexOf("okay"));
	System.out.println(w.indexOf('u'));
	String s2="java string";
	String r=s2.concat("hjk jkh hjk ");
	System.out.println(r);
	for(String i:w.split(" ",3)){System.out.println(i);}
	//String ss=String.("-","uuu","jjjj","ttt");
	
	String name="sonooo kumar";
	String sf=String.format("String name %s", name);
	System.out.println(sf);
	String sft=String.format("String name is %s", name);
	System.out.println(sft);
	String srp=name.replace('o', 'u');
	System.out.println(srp);
	
	String names="this is shiva kumar is good people";
	String named=names.replace("is", "was");
	System.out.println(named);
	System.out.println(named.substring(5));
	System.out.println(named.substring(5,9));
	
	 
	
}
}
