package String.MethodExamples;

public class StringSpliting {
public static void main(String[] args) {
	// finding out the how many times it repeating
	String s1="jjjkjk kkk fdffffd f ";
	String s2="Rajkumar ";
	String[] s3=s2.split("");
	char[] s4=s1.toCharArray();
	System.out.println(s3.length);//opt:9
	System.out.println(s2.indexOf("j"));//opt:2
	System.out.println(s2.charAt(4));
	System.out.println("**  "+s2.codePointAt(3));
	System.out.println(s2.concat(" simha"));//Rajkumar simha
	System.out.println(s3.length);//9
	System.out.println(s1.matches("f"));
	String s5="f";
	System.out.println(s1.contains("f"));
	System.out.println(s1.contains("n"));
	System.out.println(s4.length);
	char tt='f';int flag1=0;char mm='j';int flag2=0;
	for(char c:s4){
		if(tt==c){   flag1++;  }
		if(mm==c){   flag2++;  }	
	}System.out.println(tt+" ="+flag1+"  "+mm +" ="+flag2);

	String[] s6=s1.split("");
	String f="f";String j="j";String k="k";int count1,count2=0;count1=0;int count3=0;
	for(String n:s6){
		if(f.equals(n)){count1++;}
		if(j.equals(n)){count2++;}
		if(k.equals(n)){count3++;}
	}System.out.println("f="+count1+"  j="+count2+"  k="+count3);
	int count=0;
	for(CharSequence n:s6){
		if(f.contains(n)){count++;}
		/*if(j.equals(n)){count2++;}
		if(k.equals(n)){count3++;}*/
	}System.out.println("\t f="+count1);
	
	String d="how are you ? what are you doing";String[] dd=d.split("");
	String e="e";String u="u";String a="a";String r="r";int counter1=0;int counter2=0;
	int counter3=0;int counter4=0;String o="o";int counter5=0;
	for(int n=0;n<dd.length;n++){
		System.out.print(" "+dd[n]);
		if(dd[n].equals(e)){ counter1++; }
		if(dd[n].equals(u)){ counter2++; }
		if(dd[n].equals(a)){ counter3++; }
		if(dd[n].equals(r)){ counter4++; }
		if(dd[n].equals(o)){ counter5++; }
	}
System.out.println("\n e="+counter1+" a="+count3+" u="+counter2+" r="+counter4+" o="+counter5);
}
}
