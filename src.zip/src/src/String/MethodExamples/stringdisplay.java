package String.MethodExamples;

public class stringdisplay {

	 
	public static void main(String[] args) {
	// find out vowels =a,e,i,o,u
		String s="hello how are you ";
		
		char[] s1=s.toCharArray();//first way using toCharArray()
		char A,E,I,O,U;		int flag=0;
		A='a';E='e';I='i';O='o';U='u';
		for(int i=0;i<s1.length-1;i++){
		if(s1[i]==A ||s1[i]==E ||s1[i]==I ||s1[i]==O ||s1[i]==U){flag++;}	
		}
	System.out.println("No char of Vowels"+flag);flag=0;
	
	for(int j=0;j<s.length();j++){  //3rd way best way
		if(s.charAt(j)=='a'||s.charAt(j)=='e'||s.charAt(j)=='i'||s.charAt(j)=='o'||s.charAt(j)=='u'){
			flag++;
		}}System.out.println("no of charAt  "+flag);flag=0;
	
		String[] s2=s.split("");// second way using split()
		String a,e,i,o,u;  a="a";e="e";i="i";o="o";u="u";
		
		for(int m=0;m<s2.length-1;m++){
			if(s2[m].equals(a) ||s2[m].equals(e)||s2[m].equals(i)||s2[m].equals(o)||s2[m].equals(u))
			{flag++;}
		
			}System.out.println("No string of Vowels   "+flag);
			
			//String reverse order 1
			String[] s5=s.split("");System.out.println("jgdl");
		for(int j=s5.length-1;j>=0;j--){
			 System.out.print(s5[j]  );
		}	System.out.println("    jgdl");int count=0;int counter=0;
		for(int j=s.length()-1;j>=0;j--){
			 System.out.print(s.charAt(j));
			 if(s.charAt(j)=='e'){count++;}
			 
		}System.out.println("\n e="+count);
//		for(CharSequence j:s5){
//		if(s.contains(j)=='e'){}}
	}
	}
