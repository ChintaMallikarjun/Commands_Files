package String.MethodExamples;

public class stringReverseOrder {
public static void main(String[] args) {
	String s="simhadri raju . avula";
	 
	int counter=0;
	 char[] s2=s.toCharArray();
	for(char r:s2){System.out.print(" "+r);}
	
// 1. Good way of string reverse order
	System.out.println("\n 1st  Reverse Order");
	for(int i=s2.length-1;i>=0;i--){System.out.print(" "+s2[i]);
	if(s2[i]==' '){counter++;}
	} 
	 
 System.out.println("\n spaces =' ' ="+counter);
 // 2.Excellent way of string reverse order
 System.out.println("2nd way");
 for(int i=s.length()-1;i>=0;i--){
	System.out.print(" "+ s.charAt(i));
 }
  
 System.out.println("\n3rd way");
 
 //3. Easiest way
 String[] m=s.split(""); 
 for(int i=m.length-1;i>=0;i--){
	 System.out.print(" "+m[i]);
 }
 
 //1.finding about how many times it rotating
 
}
}
