package String.Examples;


public final class Employe{  
final String pancardNumber;  
  
 Employe(String pancardNumber){  
this.pancardNumber=pancardNumber;  
}  
  
public String getPancardNumber(){  
return pancardNumber;  
}  
  
}  

	class ImutableDemo{
		public static void main(String[] args) {
			Employe e=new Employe("hixy9845");
		//	Employe e1=e.getPancardNumber()+" modify";
			System.out.println(e.getPancardNumber()+" how do you do");
		}
	}