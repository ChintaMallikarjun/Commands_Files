package String.Examples;

public class Q {
 private void a(){
	System.out.println("hi how are you");}
 
void r(){a();}
Q(){
	System.out.println("**************");
	}
public int u(){ return 6;}
}

class t{
	public static void main(String[] args) {
		Q f= new Q();
		f.r();
	}
}