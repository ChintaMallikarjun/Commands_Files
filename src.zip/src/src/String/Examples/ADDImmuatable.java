package String.Examples;

public final class ADDImmuatable {

private Integer s;

//public Immuatable(){}

public ADDImmuatable(Integer s){this.s=s;}	


public  ADDImmuatable getModify(Integer s){
		if(this.s==s){
			return this;
		}else {
			return  new ADDImmuatable(s);
		}
		}
}

class OurMainTest{
	public static void main(String[] args) {
		ADDImmuatable t=new ADDImmuatable(9);
		
		ADDImmuatable t2=t.getModify(25);
		System.out.println(t==t2);
		if(t==t2)
			System.out.println(" it is same not Immutable");
		else 
			System.out.println(" t = "+t+"it is immutable \n t2 = "+t2);
	}
}