package String.Examples;

import javax.management.ImmutableDescriptor;

public final class MyimuttabilityClass {
	
	public static void main(String[] args) {
		Imuttable t=new Imuttable(4);
		Imuttable t1=t.modify(6);
		Imuttable t2=t.modify(4);
		System.out.println(t==t2);
		System.out.println(t1==t2);
		
	}
}

		final class Imuttable{
			int s;
			public Imuttable(int s) {
			 this.s=s;
			}
			
			public Imuttable modify(int s){
			
				if(this.s==s){
				return this;	
				}
				else{
					return new Imuttable(s);}
			 		}
		}