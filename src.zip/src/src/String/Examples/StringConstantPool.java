package String.Examples;

public class StringConstantPool {

public static void main(String[] args) {

String s1=new String("raj");
String s2=new String("raj");
String s3="raj";
String s4="raj";
 System.out.println(s4==s3);
}
}
