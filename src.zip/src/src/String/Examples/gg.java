package String.Examples;

public class gg {
public static void main(String[] args) {
	
	String s="RAMUDU MALII";
	String s1="";
	for(int i=s.length()-1;i>=0;i--){
		s1=s1+s.charAt(i);
		
	}System.out.println(s1);
	String[] s3=s.split("");
 
	
	for(int i=s3.length-1;i>=0;i--){
		System.out.print(s3[i]);}
		 
}
}