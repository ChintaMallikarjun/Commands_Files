package src2.test;

public class u {

	
	
public u() {
	// TODO Auto-generated constructor stub
System.out.println("jkj jk jhjhj hjkkk **********b kjk");
}	
	
	
}


class h{
private	static h g=m1();
	public h() {
		// TODO Auto-generated constructor stub
	System.out.println("hjjjjjjjjjj");
	}
	
	public static h mH(){
		
		return g;
	}
	
	public static void main(String[] args) {
		//h h=new h();
		//u uu=new u();
	}
private	static h m1(){
		return new h();
	}
}




class uuu{
	static uuu j;
	private uuu(){
		System.out.println("hai fkldh ");
			}
	public static uuu jj(){
		System.out.println("");
		if (j==null)
			j=new uuu();
		
		return j;
	}
	
	public String equals() {
		//System.out.println("hhhhhhhhhhhh");
		return "how are u";
	}
	public int hashCode(){
		return 9;
	}
	public String toString() {
	//	return "*************"+" 8888 ";
		
		return " hashCode()="+hashCode()+"   equals()= "+equals();
	}
}


class cuuc{
	public static void main(String[] args) {
		uuu t= uuu.jj();
	//	System.out.println(t.equals());
		System.out.println(t);    //out pt=*************" 8888
		System.out.println(t);    //out pt=*************" 8888
		
	}
}




