package src2.test;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public class k {
	k hm;
	public k(){
		System.out.println(hm);
	}
	public boolean m(){
		
		HashMap<String,Integer> hm=new HashMap<String,Integer>();
		
		hm.put("raju id", 101);
		hm.put("rajum id", 001);
		
		System.out.println(hm);
		
		Set y=hm.entrySet();
		System.out.println(y);
	return false;
		
	}

}

class pj{
	public static void main(String k[]){
		k k1=new k();
		//System.out.println(k1.m());
	}
}