package src2.test;

class inheritence {
	
	public void m(){
		System.out.println("hai m");
	}
	
	public void m(int a){
		System.out.println("int "+a);
	}
	
	public void m(float a){
		System.out.println("float "+a);
	}
	
}

 class p extends inheritence {
	
	public void u(){
		System.out.println("hai p");

	}
	
}
class main1{
	public static void main(String[] args) {
		
		inheritence i=new inheritence();
		i.m();
		i.m(2);
		inheritence uu= new p();
		uu.m(); 
	//	uu.u(); parent refference cannot call the  child method
	}
}



interface Aa{public void show();}

interface Bb extends Aa{}



class Cc implements Bb{
	public static void main(String[] args) {
		System.out.println("dfdf class Cc implements Bb{  ");
		new Cc().show();
	}

//	@Override
	public   void show() {
		// TODO Auto-generated method stub
		System.out.println("how Aa  ********** *** aew y");
		
	} 
}
class y extends mm{ }

class mm{
	int a=12;
	int r(){
		System.out.println(" dfdf");
		return 2;
	}
	interface ll{
		int v();
	}
}

 	class our{
 		public static void main(String[] args) {
 			mm aa=new mm();
 			y Y=new y();
 			
 			//int m=aa.a;
 			System.out.println(aa.a);
			//aa.
		}
 	}