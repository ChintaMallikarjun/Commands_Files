package HashMapExamples;

import java.util.HashMap;
import java.util.TreeMap;

public class HashMapExamples {
public static void main(String[] args) {
	
	HashMap m=new HashMap();
	m.put("Ramu", 1);
	m.put("Rama", 2);
	m.put("Rani", 5);
	m.put("Murali",11);
	m.put("Sheker",33);
	
	System.out.println(m);
	TreeMap<String , Integer> t=new TreeMap<>(m);
	System.out.println(t);
	System.out.println(t.containsKey("Ramu"));
	System.out.println(t.containsKey("ramu"));
	System.out.println(t.containsKey("Rani"));

	t.entrySet();
	System.out.println(t);
	t.descendingMap();
	System.out.println(t.firstKey());
	System.out.println(t.lastKey());
}
}
