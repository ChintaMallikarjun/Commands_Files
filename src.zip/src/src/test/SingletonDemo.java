package test;

public class SingletonDemo {
	
	private static  SingletonDemo s=null;
	
	SingletonDemo(){
	System.out.println("how are you");	
	}
	
	public static SingletonDemo getRef(){
			if(s==null){
				return	s=new SingletonDemo();
		}
			
	return s;	
	}
}


class SingletonDemo2 {
	
	private static  SingletonDemo2 s=new SingletonDemo2();
	
	SingletonDemo2(){
		
	System.out.println("who are you");	
	
	}
	
	public static SingletonDemo2 getRef(){
		
	return	s;
		
	}
}
class SingletonDemo3 {
	
	private static  SingletonDemo3 s=null;
	
	SingletonDemo3(){
		
	System.out.println("how do you do");	
	
	}
	
	public static SingletonDemo3 getRef(){
		 System.out.println(s.toString());
	return	s;
		
	}
}


  class m1{
		public static void main(String[] args) {
			//SingletonDemo s=new SingletonDemo();
			SingletonDemo s=SingletonDemo.getRef();
			SingletonDemo s1=SingletonDemo.getRef();
			SingletonDemo s2=SingletonDemo.getRef();
			SingletonDemo s3=SingletonDemo.getRef();
			System.out.println(s);
			System.out.println(s1);
			System.out.println(s2);
			System.out.println(s3);

		}
	}
  class m{
		public static void main(String[] args) {
			//SingletonDemo s=new SingletonDemo();
			SingletonDemo2 s=SingletonDemo2.getRef();
			SingletonDemo2 s1=SingletonDemo2.getRef();
			SingletonDemo2 s2=SingletonDemo2.getRef();
			SingletonDemo2 s3=SingletonDemo2.getRef();
			System.out.println(s);
			System.out.println(s1);
			System.out.println(s2);
			System.out.println(s3);

		}
	}
	
  class m3{
		public static void main(String[] args) {
			//SingletonDemo s=new SingletonDemo();
			SingletonDemo3 s=SingletonDemo3.getRef();
			SingletonDemo3 s1=SingletonDemo3.getRef();
			SingletonDemo3 s2=SingletonDemo3.getRef();
			SingletonDemo3 s3=SingletonDemo3.getRef();
			System.out.println(s);
			System.out.println(s1);
			System.out.println(s2);
			System.out.println(s3);

		}
	}
	