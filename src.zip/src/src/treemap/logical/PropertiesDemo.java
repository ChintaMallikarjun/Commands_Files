package treemap.logical;
import java.util.*;  
import java.io.*;  
public class PropertiesDemo {

	 
	public static void main(String[] args) throws Exception{
		
		   
		//    FileReader reader=new FileReader("prop.properties");  
		      
		    Properties p=new Properties(); p.setProperty("user", "Mallikarjun") ;
		    p.setProperty("password", "2525");
	//	    p.load(reader);  
		      
		    System.out.println(p.getProperty("user"));  
		    System.out.println(p.getProperty("password"));  
		   
		}   
		
		
		
	}

 
