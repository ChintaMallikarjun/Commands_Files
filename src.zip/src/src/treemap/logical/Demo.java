package treemap.logical;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeMap;

public class Demo {
	
	public static void TreeMapTraceOut(){
		TreeMap<String, Integer> tm=new TreeMap<>();
		tm.put("raj", 88);
		tm.put("ajay", 58);
		tm.put("jai", 68);tm.put("aju", 18);tm.put("janu",44);
	System.out.println(tm.keySet());
	System.out.println(tm.entrySet());
	 
	//Set<Entry<String, Integer>> s=tm.entrySet();
	 Iterator itr=tm.entrySet().iterator();
	while(itr.hasNext()){
		Object o= itr.next();
	Map.Entry  me= (Map.Entry)o;
	System.out.println(me.getKey()+"        "+me.getValue());
	if(me.getKey().equals("jai")){
		me.setValue(55);
	System.out.println(me.getKey()+" after modification="+me.getValue());
	}
	}
		
}
//map methods are
/*1)public Object put(key,value);
2)public Object putAll(map m);  
3)public Object remove(Object key);
4)public boolean containsKey(Object key);
5)public boolean containsValue(Object value);
6)public  Set keySet();
7)public Set entrySet();
8)public Object get(Object);*/
	
public static void main(String[] args) {
	TreeMap<String, Integer> tm=new TreeMap<>();
	tm.put("raj", 88);
	tm.put("ajay", 58);
	tm.put("jai", 68);tm.put("aju", 18);tm.put("janu",44);
//System.out.println(tm.keySet());
//System.out.println(tm.entrySet());
	System.out.println(tm.values());
 for(Map.Entry m:tm.entrySet()){
	 System.out.println(m.getKey()+"  ********="+m.getValue());
 }
}
}
