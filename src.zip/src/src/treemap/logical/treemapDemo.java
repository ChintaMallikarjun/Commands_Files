package treemap.logical;

import java.io.ObjectInputStream.GetField;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class treemapDemo {
public static   void main(String[] args) {
	TreeMap<String, Integer> t=new TreeMap<>();
	t.put("jak", 5);t.put("raj", 15);t.put("pra", 51);t.put("jaki", 1);
	System.out.println("treemap ="+t);
	
	Set s=t.entrySet();
	Iterator<Object> itr= s.iterator();
	while(itr.hasNext()){
		Map.Entry  tt=(Map .Entry)itr.next();
		System.out.println("getkey = "+tt.getKey()+"    value = "+tt.getValue());
		 if(tt.getKey().equals("jak") ){
			 tt.setValue(1000);
		 }
		 
	}
//	t.clear();
	System.out.println("clear = "+t);
	TreeMap tm=(TreeMap) t.clone();
	System.out.println("treemap ="+tm.equals(t));
	System.out.println("t.lastKey()="+t.lastKey());
	System.out.println("t.firstKey()="+t.firstKey());
 	System.out.println("t.higherEntry ( )"+t.higherEntry("jaki"));
	System.out.println("t.lowerKey( )"+t.lowerKey("pra"));
	System.out.println("t.firstEntry()="+t.firstEntry());
	System.out.println("t.entrySet()="+t.entrySet());
	System.out.println("t.descendingMap()="+t.descendingMap());
	System.out.println("t.pollFirstEntry()="+t.pollFirstEntry());
	System.out.println("t.values()="+t.values());
	System.out.println("t.keySet()="+t.keySet());
	System.out.println("t.descendingKeySet="+t.descendingKeySet());
	System.out.println("t.descendingMap()="+t.descendingMap());
	System.out.println("t.navigableKeySet()="+t.navigableKeySet());
	System.out.println(t.isEmpty());
	System.out.println(t.firstKey());
	System.out.println(t.floorKey("pra"));
	System.out.println(t.firstEntry());
	System.out.println(t.floorEntry("jaki"));
			System.out.println(t.lastKey());
			System.out.println(t.lastEntry());
			System.out.println(t.lowerKey("pra"));
			System.out.println(t.lowerEntry("pra"));
			
	
	/*Iterator itr1=(Iterator) t.entrySet();
	while (itr1.hasMoreElements()) {
		type type = (type) t.nextElement();
		
	}*/
/* 1)public Object put(key,value);
 * 2)public Object putAll(Map m);
 * 3)public Object get(Object key);
 * 4)public boolean containsKey(Object key);
 * 5)public boolean containsValue(Object value);
 * 6)public Object remove(Object);
 * 7)public Set  keySet();
 * 8)public Set entrySet();
 * 
 */	
}
}
