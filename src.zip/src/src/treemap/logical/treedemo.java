package treemap.logical;

import java.util.Comparator;
import java.util.TreeSet;

public class treedemo {
public static void main(String[] args) {
	TreeSet<Integer> ts=new TreeSet<>();
	ts.add(4);ts.add(40);ts.add(104);ts.add(44);ts.add(22);System.out.println(ts);
	
	System.out.println("88888888888888888==="+ts.descendingSet());
	TreeSet tts=new TreeSet<>(new m());
	tts.add(4);tts.add(40);tts.add(104);tts.add(44);tts.add(22);System.out.println("customized order="+tts);
	
}
}
class m implements Comparator {

	@Override
	public int compare(Object o1, Object o2) {
		Integer i1=(Integer)o1;Integer i2=(Integer)o2;
		return -i1.compareTo(i2);
	}
	
}