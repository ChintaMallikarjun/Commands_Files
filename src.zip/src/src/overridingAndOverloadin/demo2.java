package overridingAndOverloadin;

public class demo2 {
public static void main(String[] args) {
thread3 t3=new thread3();
t3.start();
}
}
class thread1 extends Thread{
	public void run(){
		System.out.println("this is thread1 ");
	}
}
class thread2 extends Thread{
	thread1 t1=new thread1();
	public void run(){
		t1.start();
		try{t1.join();}catch(InterruptedException e){}
		System.out.println("this is thread2 ");
	}
}
class thread3 extends Thread{
	thread2 t2=new thread2();
	public void run(){
		t2.start();
		try{t2.join();}catch(InterruptedException e){}
		System.out.println("this is thread3 ");
	}
}