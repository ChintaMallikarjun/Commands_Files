package overridingAndOverloadin;

public class demo {
	

	
}
