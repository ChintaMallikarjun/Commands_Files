package overridingAndOverloadin;


class performance{
	public void showWork(car e){
		System.out.println("Engine is a mechine");
	}
	public void showWork(Engine e){
		System.out.println("Engine is a mechine");
	}
		
}

public class demoOfOverloading {
public static void main(String[] args) {
performance p=new performance();
p.showWork(null);
}
}


class Engine{
	public void runing(){
		System.out.println("Engine is running");
	}
}
class car extends Engine{
	public void runing(){
		System.out.println("CAR Engine is running");
	}
	}