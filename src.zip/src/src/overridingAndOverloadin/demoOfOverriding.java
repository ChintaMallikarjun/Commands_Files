package overridingAndOverloadin;

class Parent{
	public void show(String s){
		System.out.println("Parent "+s);}
}
class child extends Parent{
	public void show(String s){
		System.out.println("child "+s);}
}

public class demoOfOverriding {
	public static void main(String[] args) {
		Parent p=new Parent();
		p.show("Hai");
		child c=new child();
		c.show("Hai");
		Parent ps=new child();
		ps.show("hai");
//		child pc=(child) new Parent();
//		pc.show("hai");
	}
}

