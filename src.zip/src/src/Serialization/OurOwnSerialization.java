package Serialization;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class OurOwnSerialization {
public static void main(String[] args)throws FileNotFoundException,IOException {
	Cone d=new Cone();
	d.i=10;
	d.name="NagaRaju";
	Two t=new Two();
	System.out.println("hjkhk");
	// Here we are converting the object into file state.
	FileOutputStream fos1=new FileOutputStream("D:/One.txt");
	FileOutputStream fos2=new FileOutputStream("D:/Two.txt");
	ObjectOutputStream oos1=new ObjectOutputStream(fos1);
	ObjectOutputStream oos2=new ObjectOutputStream(fos2);
	oos1.writeObject(d);oos2.writeObject(t);
}
}

class Cone implements Serializable{
	int i;
	String name;  }

class Two extends Cone{
int r=10;
String color="green";
transient String bgcolor="pink";
}