package Serialization;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Deserialization {

	public void n(int a,float f){}
	   public void n(float f,int a){}
	  
	public static void main(String[] args) {
	String s=new String("ggg");
	  s=new String("ggg");
	  // n(10,10.0);
	try {
		FileInputStream fis1=new FileInputStream("D:/One.txt") ;
		FileInputStream fis2=new FileInputStream("D:/Two.txt") ;
		ObjectInputStream ois1=new ObjectInputStream(fis1);
		ObjectInputStream ois2=new ObjectInputStream(fis2);
		Object o=ois1.readObject();
		Object o2=ois2.readObject();
		
		Cone c=(Cone)o;
		Two  t=(Two)o2;
		System.out.println(c.i+"  name = "+c.name+" color = "+t.color+""+t.bgcolor);
		
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
}
}
