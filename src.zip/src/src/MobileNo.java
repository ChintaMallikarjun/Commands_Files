import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class MobileNo {
	public static void main(String[] args) {
	//	Pattern pattern = Pattern.compile("[7-9][0-9]{9}");
		Pattern pattern = Pattern.compile("[a-zA-Z0-9]{2,}+@[a-zA-Z]{2,}+.[a-zA-Z]{2,}");
		//localhost:80
		// [1-5][1,3]
		System.out.println("enter mono");
	Matcher matcher = pattern.matcher("a1@a.com");
	if(matcher.find()){
		System.out.println("validno ");
	}else {
		System.out.println("invalid no");
	}
	}

}


