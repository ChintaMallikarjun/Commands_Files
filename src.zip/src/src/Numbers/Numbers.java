package Numbers;
 

public class Numbers {

	public static void main1(String args) {

		for(int j=1;j<=5;j++){
		for(int i=1;i<=j;i++){
			System.out.print(i);
		}
		System.out.println();
		}
	}
	
	

	public static void main2(String args) {

		for(int j=1;j<=5;j++){
		for(int i=1;i<=j;i++){
			System.out.print(j);
		}
		System.out.println();
		}
	}

	public static void main3(String args) {
		int m=4;
	for(int j=1;j<=5;j++){
		for(int k=1;k<=m;k++){
			System.out.print(" ");
		}m--;
	for(int i=1;i<=j;i++){
		System.out.print(j);
	}
	System.out.println();
	}
}
	
	
	public static void main4(String args) {
		int m=4;
		for(int j=1;j<=5;j++){
			for(int k=1;k<=m;k++){
				System.out.print(" ");
			}m--;
		for(int i=1;i<=j;i++){
			System.out.print(j+" ");
		}
		System.out.println();
		}
	}
	
	public static void main5(String args) {
		int m=4;
		int n=1;
		for(int j=1;j<=5;j++){
			for(int k=1;k<=m;k++){
				System.out.print(" ");
			}m--;
		for(int i=1;i<=j;i++){
			System.out.print(i+" ");
		}n++;
		System.out.println();
		}
	}
	public static void main6(String args) {
		int m=4;
		int n=1;
		for(int j=1;j<=5;j++){
			
			for(int k=1;k<=m;k++){
				System.out.print("  ");
			}m--;
			for(int i=1;i<=j;i++){
			System.out.print(n+"   ");
			n++;};
			System.out.println();
			}
	}
	
	public static void main(String[] args) {
		
		main6("");
		System.out.println();
		System.out.println();
		main1(" k");
		System.out.println();
		System.out.println();
		main2(" k");
		System.out.println();
		System.out.println();
		main3(" k");
		System.out.println();
		System.out.println();
		main4(" k");
		System.out.println();
		System.out.println();
		main5(" k");
	 	
	}
	


}

