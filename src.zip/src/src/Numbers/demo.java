package Numbers;

public class demo {
public static void main(String[] args) {
		for(int i = 0; i <6; i++) {
		System.out.println();
		for (int j = i; j <6 ; j++) {
			System.out.print(" "+i);			
		}
	}
		System.out.println("1----------------------------");
	for(int i = 0; i <6; i++) {
		System.out.println();
		for (int j = 1; j <=i ; j++) {
			System.out.print(" "+j);			
		}
	}	
	System.out.println("2----------------------------");
	int m=5;;
	for(int i =1; i <6; i++){
		System.out.println();
		for (int j =1; j<=m; j++) {
			System.out.print(" ");
		}m--;
		for (int j = 1; j <=i ; j++) {
			int n=2;//System.out.print(" "+j);
			if(j==i){if(i==1){}else{
				
				System.out.print(" ");
				System.out.print(j-n); }	
			}
			else
				System.out.print(" "+j);
		}
	}	
}
}
