package javaa.io;

import java.io.File;

public class display_files {
public static void main(String[] args) {
	
	int count=0;
	File f=new File("D:/");
	String[] s=f.list();
	for(String str: s){
		count++;
		System.out.print(" , "+str);
	}
	System.out.println("\n The total no of files ="+count);
}
}
