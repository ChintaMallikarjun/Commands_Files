package Logical.prgrms;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

public class Factorial {
	
 
	public static void main(String[] args) {
		//RecursiveNo(5);
		Factorial(5);
		//fact(5);
		
}
	
	public static void RecursiveNo(int t){
		//int r=0;
		System.out.print("this is Recursive no=");
		System.out.print(t);
		while(t!=0){
			 				
				System.out.print(" "+t);--t;
			}	
		}
	 		
static	int fact(int n) {
	System.out.println();
	System.out.print("this is factorial of "+n+"! = ");
        int result=0,store=0;

   while( (n-1)!=0){
   result = (n-1) * n;		//	r=3*4=12  ==>r=2*3=6	==>r=1*2=2
   store=store+result;
   n--;
   }
  System.out.print(store);
   return store;
}
	




public static int Factorial(int t){
	int c,f=1;						// 5!=5*4*3*2*1=120
	for(c=1 ; c<=t ; c++){
		f=f*c;
	}
	System.out.println(f);
	return f;
}

	public static void RecursiveOrFactorialNo(int t){
		int r=0;
		if(t%10!=0){
			r=t%10;				// r= 33%10=3   // r=3/2 = 1
			
		}
		
		
	}
	
	

	 
}
