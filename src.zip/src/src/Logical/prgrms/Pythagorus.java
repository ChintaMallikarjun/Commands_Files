package Logical.prgrms;

public class Pythagorus {

	 
		 
		   /**
		    * Example of use of the Math.sqrt() (Square root),
		    * and Math.pow() (to the power of) methods.
		    * We'll use Pythagoras Theorem for this example
		    */
		 
		   public static void main(String[] args) {
		       
		      // Calculate the length of the hypotenuse 
		      // given the base and height
		       
		      double base = 10;
		      double height = 15;
		      double hypotenuse = Math.sqrt((base * base) + (height * height));
		      System.out.println(hypotenuse);
		       
		      // If we know the base and the hypotenuse
		      // Calculate the height
		       
		      base = 3;
		      hypotenuse = 10;
		      height = Math.sqrt((hypotenuse * hypotenuse) - (base * base));
		      System.out.println(height);
		       
		      // Lastly we know the height and the hypotenuse
		      // Calculate the base
		      // Use Math.pow() here just to show alternative
		       
		      height = 7;
		      hypotenuse = 11;
		      base = Math.sqrt(Math.pow(hypotenuse, 2) - Math.pow(base, 2));
		      System.out.println(base);
		   }
		 
	
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
}
