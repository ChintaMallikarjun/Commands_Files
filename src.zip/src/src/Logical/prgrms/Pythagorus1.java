package Logical.prgrms;

public class Pythagorus1 {

	/*A Pythagorean triplet is a set of three 
	natural numbers, a, b and c, for which a2 + b2 = c2.
				32+42=52  ===>   9+16=25 and another no is 200(2)+375(2)=425(2)
			For example, 32 + 42 = 9 + 16 = 25 = (52).

			There exists exactly one Pythagorean triplet 
			for which a + b + c = 1000. Find the product abc.
	*/
	public static void main(String[] args) {
        int sum = 1000;
        int a;
        int product=0;
        for (a = 1; a <= sum/3; a++)
        {
            int b;
            for (b = a + 1; b <= sum/2; b++)
            {
                int c = sum - a - b;
                if ( c > 0 && (a*a + b*b == c*c) )
                   System.out.printf("a=%d, b=%d, c=%d\n",a,b,c);
                    product = a * b * c;
            }
        }
        System.out.println(product);
    }
}
