package Logical.prgrms;

public class ArmstrongNo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		//ArmStrong no=153  ==1*1*1+5*5*5+3*3*3=
		for(int i=1;i<1000;i++){
		int orgno=i;
		int dupno=orgno;
		int calno=0;
		while(dupno!=0){
			int digit=dupno%10;			// 153 % 10=3,5,1      ==>3*3*3=27+125+1=153  //49*7=343
			calno=calno+(digit*digit*digit);
			dupno=dupno/10;
		}
		if(calno==orgno)
		{System.out.println(calno);};
	}	
	//370  ==>0+27+343           //6
		

	}

}
