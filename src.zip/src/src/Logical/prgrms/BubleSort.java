package Logical.prgrms;

public class BubleSort {

	public static int BubleSort(int array[]){
		
		int i,a,b=0,temp=0;
		 b=array.length-1;
		for(a=0 ; a<b ; a++){
			for(i=1; i<=b; i++){
				if(array[i-1]>array[i]){		//		5>2
					
					temp=array[i-1];
					array[i-1]=array[i];
					array[i]=temp;
				}
			}
			
		}
		System.out.println(" ************   "+b);
		
		return 0;
	}
	
	
	public static void main(String[] args) {
		 int intArray[] = new int[]{5,90,35,45,150,3};
		 for(int j=0;j<intArray.length-1;j++){
			 System.out.print(intArray[j]+" ");
		 }
		BubleSort( intArray);
		System.out.println();
		for(int j=0;j<intArray.length-1;j++){
			 System.out.print(intArray[j]+" ");
		 }
	}
}
