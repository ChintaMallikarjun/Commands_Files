package Logical.prgrms;

public class SwapingNumbers {

	//static int a=22,b=33;
	 // this two numbers swapping without third element
	
	 public static void  SwappingWithVariable(int t,int r){
			System.out.println(" SwappingWithVariable");
		 
		 System.out.println("Before Swapping ="+t +" "+r);
		 
		// this.a=t;this.b=r;
		 int flag=0;
		 flag=t;
		 t=r;
		 r=flag;
		 System.out.println("After Swapping ="+t +" "+r);
		 
	 }
	 
	 public static void  SwappingWithoutVariable(int t,int r){
		 
		 System.out.println(" SwappingWithoutVariable");
			
		 System.out.println("Before Swapping ="+t +" "+r);
		 
		// this.a=t;this.b=r;
		/* int flag=0;
		 flag=t;
		 t=r;
		 r=flag;*/
		 						//t=3 r=6   
		 						//t=3+6=9
		 				t=t+r;		//t=9
		 				r=t-r;		//r=9-6=3    ==>      r=3;
		 				t=t-r;		//t=9-3=6	 ==>	  t=6
		 
		 						//t=6  r=3
		 
		 
		 System.out.println("After Swapping ="+t +" "+r);
		 
	 }
	 
	 
	 
	 
	 public static void main(String[] args) {
		// TODO Auto-generated method stub
	//	 SwappingWithVariable( 5,8);
		 SwappingWithoutVariable(3,6);
	 	
		
	}

}
