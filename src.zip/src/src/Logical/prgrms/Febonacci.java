package Logical.prgrms;

public class Febonacci {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int f1,f2,f;
		f1=0; 
		f2=1;
		f=f1+f2;		// f=1
		System.out.print("Feboncci series = "+f1+" "+f2+" "+f+" ");	//0 1 1
		
		for(int i=0;i<4;i++){
			
			f1=f2;		//f1=1	1	2	3
			f2=f;		//f2=1	2	3	5
			f=f1+f2;	//f3=2	3	5	8
			System.out.print(f+" ");		//  2	3	5	8
			
			// out put = 0	1	1	2	3	5	8
		}
		

	}

}
