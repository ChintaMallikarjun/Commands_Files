package src1;

public class Super {
	int i=10;
	int j=20;
	public void display()
	{
	System.out.println("Super  Display");		
	}
	public  void Staticdisplay()
	{
	System.out.println("Super Static Display");	
	}

}
class sub extends Super
{
	int i=10;
	int j=20;
	public void display()
	{
	System.out.println("Sub  Display");	
	}
	public void Staticdisplay()
	{
	System.out.println("Sub Static Display");	
	}
}
