package src1;

public class Overriding {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Super s=new sub();
      s.display();
      
      s.Staticdisplay();
	}

}
