package src1;
import java.io.InputStream;
import java.util.Scanner;


public class OneExample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scaner=new Scanner(System.in);
		System.out.println("Please endter veluer");
		//scaner.nextLine();
		String string=scaner.nextLine();
		System.out.println("The value is called as"+string);		
		String srs[]=string.split(":");
		int houres=Integer.parseInt(srs[1]);
		String mits=srs[2];
		String sec=srs[3];
		switch(houres)
		{
			case 1:
				System.out.println("Teh time 1 o clock");
				break;
				
			case 2:
				System.out.println("Teh time 1 o clock");
				break;
			case 3:
				System.out.println("Teh time 1 o clock");
				break;
			case 4:
				System.out.println("Teh time 1 o clock");
				break;
		}
		
		
		
		
		
	}

	private static void swatch() {
		// TODO Auto-generated method stub
		
	}

}
