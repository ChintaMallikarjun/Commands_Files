package src1;
import java.util.ArrayList;
import java.util.Collections;
import java.util.StringTokenizer;

 
  class OneSystem {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		String strs="sreenu";
		String str="sreenu h r u";
		System.out.println();
		String s[]=str.split(" ");
		System.out.println(s.length);
		
		
		
		for(int i=0;i<=s.length-1;i++)
		{
		System.out.println(s[i]);
		}
		
	System.out.println(	str.trim());
			//matches("u"));
		
		
		
		System.out.println("reverse order");
		System.out.println("&&&&");
		ArrayList list= new ArrayList();
	 list.add("g");
	 list.add("e");
	 list.add("h");
	 list.add("a");
	 list.add("e");
	 
	 Collections.rotate(list, 0);
	 System.out.println("rotate"+list);
	 System.out.println("original ="+list);
	 Collections.sort(list);
	 System.out.println("sort list ="+list);
Collections.reverse(list);
System.out.println("reverse list = "+list);
	 
	 System.out.println("&&&&&&&");
	// System.out.println(list.8);
		for(int i=s.length-1;i>=0;i--)
		{
		System.out.print(s[i]+" *");
		}
		System.out.println();
	
		StringTokenizer ts= new StringTokenizer(" this is rasi");
		System.out.println("stringtokenizer");
		while(ts.hasMoreTokens()){System.out.println(ts.nextToken());
			
		}
		
	/*for(int i=strs.length();i>0;i--)
		{
		System.out.print(strs.charAt(i));
		}
		*/
}
}







class inheritence {
	
	public void m(){
		System.out.println("hai m");
	}
	public void m(int a){
		System.out.println("int "+a);
	}
	
	public void m(float a){
		System.out.println("float "+a);
	}

}

 class p extends inheritence {
	 public void m(){
			System.out.println("hai mpp");
		}
	public void u(){
		System.out.println("hai p");

	}
	
}
class main1{
	public static void main1(String[] args) {
		
		inheritence i=new inheritence();
		i.m();
		i.m(2);
		inheritence uu= new p();
		uu.m();
		//uu.u(); parent refference cannot call the  child method
	}
}


class mythrow{
	
	public static void main(String[] args) {
	
		throw new ArithmeticException(" ************ ");
		
	}
	
}



class d extends Exception{
	 
	 public d( String s) {
		// TODO Auto-generated constructor stub
		 super(s);
	}
}

class Demo1{
	 
	 public static void main(String[] args) throws d {
		if(1==1){
		throw new d("raising exception here");	 
		}
	}
}









