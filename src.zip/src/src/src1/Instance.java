package src1;
class Instance {
   static int i;
   
   public static void main(String[] args) {
	
	System.out.println(i);
}
}
	/*static
	{
		i=10;
	}
	void m1()
	{
		i=20;
	}
	
	
	
}
*/