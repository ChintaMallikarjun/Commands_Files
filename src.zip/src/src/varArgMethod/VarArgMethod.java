package varArgMethod;

public class VarArgMethod {
	String sags = null;
	int x;
	public static void varArgMethodDemo(String...  sags){		//type  1
		System.out.println("THis is method="+sags);
	}
	public static void m(int...x){System.out.println("this ="+x);}	//type	2
	public static void m1(int  ...x){System.out.println("this ="+x);}//type	3
	@Override
	public String toString() {
		//this.sags;
		return sags+"";
	}
	public static void main(String[] args) {
		varArgMethodDemo("hi");
		varArgMethodDemo("hi","yeah");
		varArgMethodDemo("how","do","you");
		varArgMethodDemo("ki");
		m(5);
		m(51);
		m(15);
		m(9);
	}
}
