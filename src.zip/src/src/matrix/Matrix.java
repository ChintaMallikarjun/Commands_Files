package matrix;

import java.util.ArrayList;
import java.util.Collections;

public class Matrix {public String b="How do you do";
public static void main(String[] args) {
	Matrix a=new Matrix();
	String c=a.b;
	 	System.out.println(a.b);
	 	
	 	int[] t1={1,3,6,2};
	 	int[] t2={5,8,3,3};
	 	int[] t3={3,5,0,0};
	 	ArrayList list=new ArrayList<>();
	 	list.add(t1);
	 
	 	
	 		System.out.println("Matrix = \n");
	 		for(int j=0;j<=t2.length-1;j++){
	 			System.out.print("   "+t1[j]+"   "+t2[j] +"  "+t3[j]);
	 			System.out.println();
	 		}
	 	
	 //	Collections.sort(list);
	 	System.out.println(t1);
}
}
