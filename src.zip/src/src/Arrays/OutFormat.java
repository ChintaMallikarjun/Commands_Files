package Arrays;

public class OutFormat {

	 
	public static void main(String[] args) {
 
		System.out.format("*/* "+1, "");
	int	rows=9;
		for(int i=1;i<9;i++){
			
		System.out.format("*"+(rows-i),"");}
		
	}
}
