package Arrays;

public class commonArrayget {
	
	
//	int 
	
	
	
	

}
