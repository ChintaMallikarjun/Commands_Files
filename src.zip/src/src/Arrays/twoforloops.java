package Arrays;

public class twoforloops {

	
	
	
	
	
	
	
	
	
	
}
