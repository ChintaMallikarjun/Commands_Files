package thread;

import java.io.IOException;

public class thread {
public static void main(String[] args) {
	DistributionWeddingCards t3=new DistributionWeddingCards();
	t3.start();
	/*PrintingWeddingcards t2=new PrintingWeddingcards();
	t2.start();
	FixingMarriage t1=new FixingMarriage();
	t1.start();*/
}
}

class FixingMarriage extends Thread{
	public void run(){
		System.out.println("fixing the  marrieage date ");
	}
}

class PrintingWeddingcards  extends Thread{
	FixingMarriage t1=new FixingMarriage(); 
	public void run(){
		try{t1.start();
			t1.join();
		}catch(InterruptedException e){e.printStackTrace();}
		System.out.println(" PrintingWeddingcards date ");
	}
}
class DistributionWeddingCards  extends Thread{
	PrintingWeddingcards t2=new PrintingWeddingcards();;
	public void run(){
		try{t2.start();
			t2.join();}catch(InterruptedException e){e.printStackTrace();}
		System.out.println("DistributionWeddingCards date ");
	}
}
