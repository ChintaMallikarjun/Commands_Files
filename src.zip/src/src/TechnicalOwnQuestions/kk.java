package TechnicalOwnQuestions;

public class kk {
public static void main(String[] args) {
	
}
public String name(int a) {
		return "hi";
	}
public Object name() {
	return "hai";
}

}
