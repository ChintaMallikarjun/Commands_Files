package TechnicalOwnQuestions;

public class technical {

	public void m1(String s){System.out.println("hjjhj hjh ");}

	public static void main(String[] args) {
		technical a=new technical();
		a.m1("");
		a.m2();
		try{
		int i=4/0;
			
		}catch(ArithmeticException e){
			 System.out.println(" 8888");
		}catch (Exception e) {
			 System.out.println("h        hhhhh");}
		try{}
		catch (ArrayIndexOutOfBoundsException e) {
			 System.out.println("h        hhhhh");
		
		}
		 		
		System.out.println();	 
		
	}
	public int m2() {try{
		int a=9;
	try{
		int n=8;
	}catch (Exception e) {
		// TODO: handle exception
	} 
	}finally{return 99;}
	 //System.out.println();
	}
		 
	
	 
}
