package ArrayListPractice;


import java.util.ArrayList;
 

public class onemoreExample {
 
	public static void main(String[] args) {
		// List   l2=new ArrayList<>();
		ArrayList<String> ls=new ArrayList<>();
		ls.add("raju");
		ls.add("ramu");
		ls.add("ravi");
		ls.add("raki");
		ls.add("akil");
		ls.add("prdeep");
		System.out.println(ls);
	  java.util.List<String>  l2=	ls.subList(2, 6);
		System.out.println(l2);
	}

}

class C {
	public void main(String[] args) {
		int f =0, n= 2, r=20;
	
	}
	
	static int febNum(int f, int range) {
		Integer i = null;
			return i.intValue();	
	}
	
	
}

class C1 extends C {
	public void main(String[] args) {
		int f = 0, n = 2, r = 20;
	
	}
	
	static int febNum(int f, int range) {
		Integer i = null;
			return i.intValue();	
	}
	
	
}


