package identifiers;

public class LocalVariable {

	 public static void main(String[] args) {
 
		 
		 
		 for(int i=0;i<10;i++){
			 System.out.print(" "+i);}
//		 System.out.println(i); c.er;
		 
		 
	}

}
